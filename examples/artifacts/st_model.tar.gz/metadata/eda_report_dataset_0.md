# ML-Focused Data Analysis Report: dataset_0

Generated: 2025-05-21T17:03:52.646373

## Essential Dataset Overview

**Dataset Size**: 8693 rows x 22 columns

### Target Distribution

**True (Transported)**: 49.64%

**False (Not Transported)**: 50.36%

**Target Balance**: Well balanced (approximately 50/50 split)

### Missing Values

**Total Missing Percentage**: 1.79%

**Columns With Missing Values**: All columns except 'Transported' have missing values (approximately 2% per column)



## Feature Engineering Opportunities

**Cabin Decomposition**: Split Cabin into Deck, Number, and Side components for better predictive power

**Spending Features**: Create TotalSpend feature from the sum of all spending categories

**Vip Status**: Create VIP indicator based on high spending (top 10%)

**Group Travel**: Create GroupSize and IsGroup features based on cabin number to identify group travelers

### Interaction Features

- CryoSleep × HomePlanet has strong interaction effect on transport status

- Deck × VIP status shows interesting patterns for transport prediction

- Age × HomePlanet may provide additional insights



## Data Quality Challenges

**Missing Values**: Approximately 2% missing values across most columns

**Missing Pattern**: Missing values appear to be distributed similarly across transported and non-transported groups (likely MCAR)

**Spending Outliers**: Large outliers in spending features with extremely high values

**Zero Inflation**: High number of zero values in spending features, particularly for passengers in CryoSleep



## Data Preprocessing Requirements

**Imputation**: Simple imputation strategies can be used for missing values (~2% per column)

### Categorical Encoding

- HomePlanet, Destination: Label or one-hot encoding

- CryoSleep: Convert to binary numeric

- Cabin: Extract Deck, Number, Side components first, then encode

**Feature Scaling**: Normalize or standardize spending features due to wide range of values

**Handling Zero Inflation**: Create binary indicator features for any spending



## Feature Importance Analysis

### High Importance Features

- CryoSleep (information gain: 0.168)

- TotalSpend (correlation: -0.198)

- Cabin components (especially Deck)

- HomePlanet (information gain: 0.028)

### Medium Importance Features

- Age (correlation: -0.075)

- Individual spending categories

- GroupSize/IsGroup feature

### Low Importance Features

- Destination (information gain: 0.009)

- Side of cabin



## Key ML Insights

- CryoSleep is the strongest predictor of transport status (over 80% of passengers in CryoSleep were transported)

- Passengers with high spending (VIPs) were less likely to be transported (34% vs 52% for non-VIPs)

- Spending patterns strongly differ between transported and non-transported passengers, with non-transported spending 2x more overall

- Home planet has significant effect: Europa passengers were more likely to be transported (66% vs 42% Earth, 52% Mars)

- Deck matters: B and C deck passengers were much more likely to be transported (73% and 68% respectively) vs other decks

- CryoSleep passengers spent nothing in any category (likely a deterministic relationship)

- Group travelers were slightly more likely to be transported than solo travelers



## Actionable Recommendations

- Start with simple Decision Tree using CryoSleep, HomePlanet, Deck, and TotalSpend as primary features

- For Linear Regression (Logistic): Include encoded categorical variables and normalized spending features

- Consider separate models or special handling for CryoSleep passengers due to their distinct spending patterns

- Impute missing values with simple strategies (mean/median for numeric, mode for categorical)

- Engineer TotalSpend and IsVIP features to capture spending patterns

- Extract Deck from Cabin as it's more predictive than the full Cabin value

- Include binary indicator for any spending (vs. zero spending) as feature
