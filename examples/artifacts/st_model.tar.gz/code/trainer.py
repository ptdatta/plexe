
import pandas as pd
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.preprocessing import OneHotEncoder, MinMaxScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import make_pipeline
from sklearn.compose import ColumnTransformer
from sklearn.metrics import accuracy_score
from joblib import dump

# File paths
train_file = "dataset_0_train.parquet"
val_file = "dataset_0_val.parquet"

# Load datasets
train_data = pd.read_parquet(train_file)
val_data = pd.read_parquet(val_file)

# Features and target
features = [
    "HomePlanet",
    "CryoSleep",
    "Destination",
    "Age",
    "RoomService",
    "FoodCourt",
    "ShoppingMall",
    "Spa",
    "VRDeck",
    "Deck",
    "TotalSpend",
    "IsVIP"
]
target = "Transported"

# Print data information
print("Dataset shapes:")
print(f"Training data: {train_data.shape}")
print(f"Validation data: {val_data.shape}")

# Check for missing values
print("\nMissing values in training data:")
print(train_data[features].isnull().sum())

# Convert CryoSleep from string to boolean if needed
if train_data["CryoSleep"].dtype == "object":
    train_data["CryoSleep"] = train_data["CryoSleep"].map({"True": True, "False": False})
    val_data["CryoSleep"] = val_data["CryoSleep"].map({"True": True, "False": False})

# Preprocessing steps
categorical_features = ["HomePlanet", "Destination", "Deck"]
binary_features = ["CryoSleep", "IsVIP"]
numerical_features = [
    "Age",
    "RoomService",
    "FoodCourt",
    "ShoppingMall",
    "Spa",
    "VRDeck",
    "TotalSpend"
]

# Column transformer for handling different preprocessing steps
preprocessor = ColumnTransformer(
    transformers=[
        ("cat", make_pipeline(
            SimpleImputer(strategy="most_frequent"),
            OneHotEncoder(handle_unknown="ignore")
        ), categorical_features),
        ("num", make_pipeline(
            SimpleImputer(strategy="median"),
            MinMaxScaler()
        ), numerical_features),
        ("bin", SimpleImputer(strategy="most_frequent"), binary_features),
    ],
    remainder="drop"
)

# Training Logistic Regression Model
print("\nTraining Logistic Regression Model...")
logistic_pipeline = make_pipeline(preprocessor, LogisticRegression(solver="liblinear"))
logistic_pipeline.fit(train_data[features], train_data[target])

# Save the logistic regression model
dump(logistic_pipeline, "logistic_regression_model.joblib")

# Evaluate Logistic Regression Model
val_predictions_logistic = logistic_pipeline.predict(val_data[features])
accuracy_logistic = accuracy_score(val_data[target], val_predictions_logistic)
print(f"Logistic Regression Accuracy: {accuracy_logistic:.4f}")

# Training Decision Tree Model
print("\nTraining Decision Tree Model...")
decision_tree_pipeline = make_pipeline(
    preprocessor, DecisionTreeClassifier(max_depth=3, random_state=42)
)
decision_tree_pipeline.fit(train_data[features], train_data[target])

# Save the decision tree model
dump(decision_tree_pipeline, "decision_tree_model.joblib")

# Evaluate Decision Tree Model
val_predictions_tree = decision_tree_pipeline.predict(val_data[features])
accuracy_tree = accuracy_score(val_data[target], val_predictions_tree)
print(f"Decision Tree Accuracy: {accuracy_tree:.4f}")

# Compare models and select the best one
print("\nModel Comparison:")
print(f"Logistic Regression Accuracy: {accuracy_logistic:.4f}")
print(f"Decision Tree Accuracy: {accuracy_tree:.4f}")

# Select the best model and report its performance
if accuracy_logistic > accuracy_tree:
    print("\nLogistic Regression performs better.")
    best_model = "logistic_regression_model.joblib"
    best_accuracy = accuracy_logistic
else:
    print("\nDecision Tree performs better.")
    best_model = "decision_tree_model.joblib"
    best_accuracy = accuracy_tree

print(f"Best model saved as: {best_model}")
print(f"Best model accuracy: {best_accuracy:.4f}")

# Print a specific format for the execution tool to extract the performance metric
print(f"accuracy: {best_accuracy}")
