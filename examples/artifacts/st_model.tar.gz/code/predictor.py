
from typing import List, Dict, Any, Optional
import pandas as pd
import numpy as np
from joblib import load
import os

from plexe.internal.models.entities.artifact import Artifact
from plexe.internal.models.interfaces.predictor import Predictor


class PredictorImplementation(Predictor):
    def __init__(self, artifacts: List[Artifact]):
        """
        Instantiates the predictor using the provided model artifacts.
        Loads both the logistic regression and decision tree models.
        
        Args:
            artifacts: List of model artifacts
        """
        # Load the logistic regression model
        logistic_model_artifact = self._get_artifact("logistic_regression_model.joblib", artifacts)
        with logistic_model_artifact.get_as_handle() as binary_io:
            self.logistic_model = load(binary_io)
            
        # Load the decision tree model
        decision_tree_artifact = self._get_artifact("decision_tree_model.joblib", artifacts)
        with decision_tree_artifact.get_as_handle() as binary_io:
            self.decision_tree_model = load(binary_io)
            
        # Default to using the logistic regression model (can be configured)
        self.model = self.logistic_model
        
        # Define feature lists for preprocessing
        self.categorical_features = ["HomePlanet", "Destination", "Deck"]
        self.binary_features = ["CryoSleep"]
        self.numerical_features = [
            "Age", "RoomService", "FoodCourt", "ShoppingMall", 
            "Spa", "VRDeck", "TotalSpend"
        ]
        self.required_features = (
            self.categorical_features + 
            self.binary_features + 
            self.numerical_features
        )

    def predict(self, inputs: dict) -> dict:
        """
        Given an input conforming to the input schema, return the model's prediction
        as a dict conforming to the output schema.
        
        Args:
            inputs: Dictionary containing input features
            
        Returns:
            Dictionary with 'Transported' prediction (boolean)
        """
        try:
            # Preprocess the input
            processed_input = self._preprocess_input(inputs)
            
            # Make prediction
            prediction = self.model.predict(processed_input)[0]
            
            # Format the output
            result = self._postprocess_output(prediction)
            
            return result
        except Exception as e:
            # Log the error (in a production environment, this would use a proper logger)
            print(f"Error during prediction: {str(e)}")
            # Return default prediction in case of error
            return {"Transported": False}

    def _preprocess_input(self, inputs: dict) -> pd.DataFrame:
        """
        Prepare the input data for model prediction.
        
        Args:
            inputs: Dictionary containing input features
            
        Returns:
            Pandas DataFrame with properly formatted features
        """
        # Convert input to DataFrame
        df = pd.DataFrame([inputs])
        
        # Handle IsVIP which is in training but not in inference input schema
        # We'll set it to False by default since it's not available in the input
        df["IsVIP"] = False
        
        # Validate and clean input data
        df = self._validate_and_clean_inputs(df)
        
        return df

    def _validate_and_clean_inputs(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Validate input data and handle missing or invalid values.
        
        Args:
            df: DataFrame containing input features
            
        Returns:
            Cleaned DataFrame ready for prediction
        """
        # Ensure all required columns are present
        for col in self.required_features:
            if col not in df.columns:
                df[col] = np.nan
        
        # Convert CryoSleep to boolean if it's a string
        if df["CryoSleep"].dtype == "object":
            df["CryoSleep"] = df["CryoSleep"].map(
                {"True": True, "False": False, True: True, False: False}
            )
            
        # Ensure all numeric features are float type
        for col in self.numerical_features:
            df[col] = pd.to_numeric(df[col], errors="coerce")
            
        # Keep only the columns used by the model
        return df[self.required_features + ["IsVIP"]]

    def _postprocess_output(self, prediction) -> dict:
        """
        Format the model prediction according to the output schema.
        
        Args:
            prediction: Raw model prediction
            
        Returns:
            Dictionary with 'Transported' prediction (boolean)
        """
        # Convert prediction to boolean and format as dictionary
        return {"Transported": bool(prediction)}

    @staticmethod
    def _get_artifact(name: str, artifacts: List[Artifact]) -> Artifact:
        """
        Given the name of a binary artifact, return the corresponding artifact from the list.
        
        Args:
            name: Name of the artifact to find
            artifacts: List of available artifacts
            
        Returns:
            The requested artifact
            
        Raises:
            ValueError: If the requested artifact is not found
        """
        for artifact in artifacts:
            if artifact.name == name:
                return artifact
        raise ValueError(f"Artifact {name} not found in the provided artifacts.")
