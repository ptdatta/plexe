from typing import List
import joblib
import numpy as np
import pandas as pd

from plexe.internal.models.entities.artifact import Artifact
from plexe.internal.models.interfaces.predictor import Predictor


class PredictorImplementation(Predictor):
    def __init__(self, artifacts: List[Artifact]):
        """
        Instantiates the predictor using the provided model artifacts.
        :param artifacts: list of BinaryIO artifacts
        """
        try:
            # Load the preprocessor artifact
            preprocessor_artifact = self._get_artifact(
                "preprocessor_unique_name.joblib", artifacts
            )
            with preprocessor_artifact.get_as_handle() as binary_io:
                self.preprocessor = joblib.load(binary_io)

            # Load the MLP model artifact
            model_artifact = self._get_artifact(
                "mlp_model_unique_name.joblib", artifacts
            )
            with model_artifact.get_as_handle() as binary_io:
                self.model = joblib.load(binary_io)
        except Exception as e:
            raise RuntimeError(f"Failed to load model artifacts: {str(e)}")

    def predict(self, inputs: dict) -> dict:
        """
        Given an input conforming to the input schema, return the model's prediction
        as a dict conforming to the output schema.
        """
        try:
            # Step 1: Preprocess the inputs
            preprocessed_inputs = self._preprocess_input(inputs)

            # Step 2: Make predictions using the loaded model
            raw_prediction = self.model.predict(preprocessed_inputs)

            # Step 3: Postprocess the raw prediction to match the output schema
            prediction_result = self._postprocess_output(raw_prediction)

            # Step 4: Return the prediction result
            return prediction_result
        except Exception as e:
            return {"error": f"Prediction failed due to: {str(e)}"}

    def _preprocess_input(self, inputs: dict):
        """Map the input data from a dict to the input format of the underlying model."""
        required_columns = {
            "Unnamed: 0": int,
            "User_ID": str,
            "Age": int,
            "Gender": str,
            "Location": str,
            "Income": int,
            "Interests": str,
            "Last_Login_Days_Ago": int,
            "Purchase_Frequency": int,
            "Average_Order_Value": int,
            "Total_Spending": int,
            "Time_Spent_on_Site_Minutes": int,
            "Pages_Viewed": int,
            "Newsletter_Subscription": bool,
        }

        # Validate input keys and types
        for key, expected_type in required_columns.items():
            value = inputs.get(key)
            if value is None or not isinstance(value, expected_type):
                raise ValueError(
                    f"Invalid input for '{key}': Expected {expected_type}, got {type(value)}"
                )

        # Convert the input dictionary to a DataFrame.
        input_df = pd.DataFrame([inputs])

        # Ensure correct data types.
        input_df = input_df.astype(required_columns)

        # Use the preprocessor to transform the DataFrame into the format expected by the model.
        processed_input = self.preprocessor.transform(input_df)
        return processed_input

    def _postprocess_output(self, outputs) -> dict:
        """Map the output from the underlying model to a dict compliant with the output schema."""
        # Extract the single prediction result, which is an array with one string element
        prediction = outputs[0]
        # Return dict conforming to the output schema
        return {"Product_Category_Preference": prediction}

    @staticmethod
    def _get_artifact(name: str, artifacts: List[Artifact]) -> Artifact:
        """Given the name of a binary artifact, return the corresponding artifact from the list."""
        # Do not modify this method.
        for artifact in artifacts:
            if artifact.name == name:
                return artifact
        raise ValueError(f"Artifact {name} not found in the provided artifacts.")