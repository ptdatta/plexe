import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder, FunctionTransformer
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score
from sklearn.impute import SimpleImputer
import joblib

# Load training data
train_data = pd.read_parquet("dataset_0_train.parquet")
val_data = pd.read_parquet("dataset_0_val.parquet")

# Correct column name and separate features and target
X_train = train_data.drop(columns="Product_Category_Preference")
y_train = train_data["Product_Category_Preference"]
X_val = val_data.drop(columns="Product_Category_Preference")
y_val = val_data["Product_Category_Preference"]

# Identify categorical and continuous features
categorical_features = X_train.select_dtypes(include=["object", "category"]).columns
continuous_features = X_train.select_dtypes(include=["float64", "int64"]).columns

# Preprocessing for categorical data - One-Hot Encoding
categorical_transformer = Pipeline(
    steps=[
        ("imputer", SimpleImputer(strategy="constant", fill_value="missing")),
        ("onehot", OneHotEncoder(handle_unknown="ignore")),
    ]
)

# Preprocessing for continuous data - Scaling and log transformation
continuous_transformer = Pipeline(
    steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("log_transform", FunctionTransformer(np.log1p, validate=True)),
        ("scaler", StandardScaler()),
    ]
)

# Combine both continuous and categorical transformers
preprocessor = ColumnTransformer(
    transformers=[
        ("num", continuous_transformer, continuous_features),
        ("cat", categorical_transformer, categorical_features),
    ]
)

# Use unique name for saved preprocessor
joblib.dump(preprocessor, "preprocessor_unique_name.joblib")

# Create an MLP model
mlp = MLPClassifier(
    hidden_layer_sizes=(100, 50),
    activation="relu",
    solver="adam",
    max_iter=200,
    alpha=0.001,
    random_state=42,
)

# Preprocess training data
X_train_processed = preprocessor.fit_transform(X_train)

# Train the MLP model
mlp.fit(X_train_processed, y_train)

# Save the trained model with a unique name
joblib.dump(mlp, "mlp_model_unique_name.joblib")

# Preprocess validation data
X_val_processed = preprocessor.transform(X_val)

# Evaluate the model using validation data
y_pred = mlp.predict(X_val_processed)

# Calculate accuracy score
accuracy = accuracy_score(y_val, y_pred)

# Print the validation accuracy
print(f"accuracy: {accuracy:.4f}")