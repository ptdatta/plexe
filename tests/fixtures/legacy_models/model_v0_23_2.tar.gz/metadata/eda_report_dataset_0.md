# ML-Focused Data Analysis Report: dataset_0

Generated: 2025-05-26T15:36:08.748761

## Essential Dataset Overview

**Rows**: 8693

**Columns**: 12

### Target Distribution

**Not Transported**: 49.64

**Transported**: 50.36

### Missing Values

**Homeplanet**: 201

**Cryosleep**: 217

**Cabin**: 199

**Destination**: 182

**Age**: 179

**Roomservice**: 181

**Foodcourt**: 183

**Shoppingmall**: 208

**Spa**: 183

**Vrdeck**: 188

**Name**: 200

**Transported**: 0

### Data Types

**Homeplanet**: object

**Cryosleep**: object

**Cabin**: object

**Destination**: object

**Age**: float64

**Roomservice**: float64

**Foodcourt**: float64

**Shoppingmall**: float64

**Spa**: float64

**Vrdeck**: float64

**Name**: object

**Transported**: bool



## Feature Engineering Opportunities

### Cabin Parsing

**Description**: Cabin field contains valuable information in format 'Deck/Number/Side'

#### Recommended Features

- Deck

- Cabin_num

- Cabin_side

### Spending Patterns

**Description**: Spending features show strong relationship with transport status

#### Recommended Features

- TotalSpend

- HasSpent

### Age Transformation

**Description**: Age shows non-linear relationship with target, binning recommended

#### Recommended Features

- AgeGroup

### Family Features

**Description**: Last name can be used to identify family groups

#### Recommended Features

- FamilySize

- TravelingAlone

### Interaction Features

**Description**: Strong interaction between CryoSleep and spending patterns

#### Recommended Features

- CryoSleep_HasSpent



## Data Quality Challenges

### Missing Values

**Description**: Several columns have missing values (up to 217 in a single column)

**Recommendation**: Imputation strategies based on relationships (e.g., CryoSleep passengers have zero spending)

### Boolean Representation

**Description**: Boolean columns stored as strings instead of actual boolean type

**Recommendation**: Convert string representations to boolean type

### Cabin Structure

**Description**: Cabin field needs parsing to extract useful information

**Recommendation**: Split into component parts before modeling

### Spending Skewness

**Description**: Spending columns highly skewed with many zeros

**Recommendation**: Log transformation or binary indicators for non-zero spending



## Data Preprocessing Requirements

### Missing Value Handling

**Description**: Impute missing values based on logical relationships

#### Details

**Cryosleep**: Impute based on spending patterns (if all spending is 0, likely in CryoSleep)

**Homeplanet**: Impute based on Cabin deck patterns or most frequent value

**Age**: Impute with median age, possibly grouped by HomePlanet

### Categorical Encoding

**Description**: Encode categorical variables appropriately

#### Details

**Homeplanet**: One-hot encoding (3 values)

**Destination**: One-hot encoding (3 values)

**Deck**: One-hot encoding (8 values)

**Cabin Side**: Binary encoding (P or S)

### Feature Scaling

**Description**: Scale numerical features for linear models

**Details**: StandardScaler for all numerical features, especially important for linear regression

### Binary Feature Creation

**Description**: Create binary indicators for specific conditions

#### Details

- HasSpent

- TravelingAlone

- IsChild



## Feature Importance Analysis

### High Importance

- CryoSleep

- Deck

- HasSpent

- HomePlanet

### Medium Importance

- Destination

- Age

- Cabin_side

- TotalSpend

- TravelingAlone

### Low Importance

- Name

- Individual spending categories



## Key ML Insights

- CryoSleep passengers are almost always transported (81.8% transport rate vs 32.9% for non-CryoSleep)

- Passengers with zero spending are much more likely to be transported (78.6% vs 29.9%)

- Cabin deck shows strong relationship with transport status (B deck 73.4% transported vs T deck 20.0%)

- Children have higher transport rates (66.9%) compared to adults (~48%)

- HomePlanet shows significant impact: Europa passengers more likely to be transported (65.9%) vs Earth (42.4%)

- Passengers traveling alone are more likely to be transported (58.4% vs 50.0%)

- Cabin side also affects transport rate (S side 55.5% vs P side 45.1%)



## Actionable Recommendations

- Create composite features combining CryoSleep and spending patterns

- Extract and encode cabin information (deck, side) as separate features

- Use age binning to capture non-linear relationship with transport status

- Create family grouping features based on last names

- Handle missing values through logical imputation rather than dropping rows

- Engineer binary features for key conditions (HasSpent, TravelingAlone, IsChild)

- Consider simple polynomial features for age (age^2) to capture non-linear effects

- For linear regression, ensure thorough feature scaling
