
from plexe.core.object_registry import ObjectRegistry
from plexe.internal.common.datasets.interface import TabularConvertible
from plexe.core.interfaces.predictor import Predictor
import pandas as pd
import numpy as np
from sklearn.metrics import accuracy_score, confusion_matrix, precision_score, recall_score, f1_score, classification_report

# Get objects from registry
object_registry = ObjectRegistry()
test_dataset = object_registry.get(TabularConvertible, "dataset_0_test")
test_df = test_dataset.to_pandas()
predictor = object_registry.get(Predictor, "trained_predictor")

# Prepare test data
X_test = test_df.drop('Transported', axis=1)
y_true = test_df['Transported'].values

# Make predictions
predictions = []
for idx, row in X_test.iterrows():
    input_dict = {}
    for col in X_test.columns:
        value = row[col]
        input_dict[col] = None if pd.isna(value) else value
    pred_result = predictor.predict(input_dict)
    predictions.append(pred_result['Transported'])

y_pred = np.array(predictions)

# Calculate metrics
accuracy = accuracy_score(y_true, y_pred)
cm = confusion_matrix(y_true, y_pred)
precision = precision_score(y_true, y_pred)
recall = recall_score(y_true, y_pred)
f1 = f1_score(y_true, y_pred)

print(f"Model Evaluation Results:")
print(f"Accuracy: {accuracy:.4f}")
print(f"Precision: {precision:.4f}")
print(f"Recall: {recall:.4f}")
print(f"F1-Score: {f1:.4f}")
print(f"Confusion Matrix:\n{cm}")
