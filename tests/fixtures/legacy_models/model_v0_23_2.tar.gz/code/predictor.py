from typing import List
import pandas as pd
import joblib
from plexe.internal.models.entities.artifact import Artifact
from plexe.core.interfaces.predictor import Predictor


class PredictorImplementation(Predictor):
    def __init__(self, artifacts: List[Artifact]):
        """
        Instantiates the predictor using the provided model artifacts.
        :param artifacts: list of BinaryIO artifacts
        """
        # Load the decision tree model
        artifact = self._get_artifact("decision_tree_model.pkl", artifacts)
        with artifact.get_as_handle() as binary_io:
            self.model = joblib.load(binary_io)

    def predict(self, inputs: dict) -> dict:
        """
        Given an input conforming to the input schema, return the model's prediction
        as a dict conforming to the output schema.
        """
        # Preprocess the input
        processed_input = self._preprocess_input(inputs)
        
        # Make prediction
        prediction = self.model.predict(processed_input)
        
        # Postprocess and return the output
        return self._postprocess_output(prediction)

    def _preprocess_input(self, inputs: dict):
        """Map the input data from a dict to the input format of the underlying model."""
        # Convert input dict to DataFrame
        df = pd.DataFrame([inputs])
        
        # Apply cabin processing (same as in training)
        df = self._process_cabin(df)
        
        return df

    def _postprocess_output(self, outputs) -> dict:
        """Map the output from the underlying model to a dict compliant with the output schema."""
        # Convert numpy array/list to boolean and return as dict
        transported = bool(outputs[0])
        return {"Transported": transported}

    def _process_cabin(self, df):
        """Process cabin column to extract Deck, Num, and Side features."""
        # Splitting cabin into separate features (same logic as training)
        df[["Deck", "Num", "Side"]] = df["Cabin"].str.extract("([A-Z])(\d+)([A-Z])")
        df.drop(columns=["Cabin"], inplace=True)
        return df

    @staticmethod
    def _get_artifact(name: str, artifacts: List[Artifact]) -> Artifact:
        """Given the name of a binary artifact, return the corresponding artifact from the list."""
        # Do not modify this method.
        for artifact in artifacts:
            if artifact.name == name:
                return artifact
        raise ValueError(f"Artifact {name} not found in the provided artifacts.")
