import pandas as pd
import numpy as np
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import joblib

# Load training and validation data
train_data = pd.read_parquet("dataset_0_train.parquet")
val_data = pd.read_parquet("dataset_0_val.parquet")

# Separate features and target
X_train = train_data.drop("Transported", axis=1)
y_train = train_data["Transported"]
X_val = val_data.drop("Transported", axis=1)
y_val = val_data["Transported"]

# Identify categorical and numerical features
num_features = X_train.select_dtypes(include=["int64", "float64"]).columns.tolist()
cat_features = X_train.select_dtypes(include=["object"]).columns.tolist()


# Define Cabin Processing Function
def process_cabin(df):
    # Splitting cabin into separate features
    df[["Deck", "Num", "Side"]] = df["Cabin"].str.extract("([A-Z])(\d+)([A-Z])")
    df.drop(columns=["Cabin"], inplace=True)
    return df


# Process training and validation data for Cabin features
X_train = process_cabin(X_train)
X_val = process_cabin(X_val)

# Re-identify features as new Cabin processing has taken place
num_features = X_train.select_dtypes(include=["int64", "float64"]).columns.tolist()
cat_features = X_train.select_dtypes(include=["object"]).columns.tolist()

# Define preprocessing for numerical data
num_transformer = SimpleImputer(strategy="median")

# Define preprocessing for categorical data
cat_transformer = Pipeline(
    steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore")),
    ]
)

# Bundle preprocessing steps
preprocessor = ColumnTransformer(
    transformers=[
        ("num", num_transformer, num_features),
        ("cat", cat_transformer, cat_features),
    ]
)

# Create the full pipeline with decision tree classifier
model = Pipeline(
    steps=[
        ("preprocessor", preprocessor),
        ("classifier", DecisionTreeClassifier(max_depth=5, random_state=42)),
    ]
)

# Train the model
model.fit(X_train, y_train)

# Validate the model
y_pred = model.predict(X_val)
accuracy = accuracy_score(y_val, y_pred)

# Output the model's accuracy score
print(f"accuracy: {accuracy:.4f}")

# Save the model and preprocessor
joblib.dump(model, "decision_tree_model.pkl")
