
# Set random state for reproducibility
RANDOM_STATE = 42

# Split data into train and temp sets (70% train, 30% temp)
train_df, temp_df = train_test_split(
    df, 
    test_size=0.3,  # 30% for temp (will be split into validation and test)
    random_state=RANDOM_STATE,
    stratify=df['Transported']  # Stratify by target variable
)

# Split temp into validation and test sets (50% validation, 50% test, which is 15% each of original)
val_df, test_df = train_test_split(
    temp_df,
    test_size=0.5,  # 50% of temp (15% of original)
    random_state=RANDOM_STATE,
    stratify=temp_df['Transported']  # Stratify by target variable
)
