
import pandas as pd
import numpy as np
from plexe.core.interfaces.feature_transformer import FeatureTransformer

class FeatureTransformerImplementation(FeatureTransformer):
    
    def transform(self, inputs: pd.DataFrame) -> pd.DataFrame:
        """
        Given a DataFrame representing a raw dataset, applies feature transformations
        and returns the transformed DataFrame suitable for training an ML model.
        
        Args:
            inputs: Input DataFrame to transform
            
        Returns:
            Transformed DataFrame with engineered features
        """
        # Make a copy to avoid modifying the original
        df = inputs.copy()
        
        # 1. Handle boolean columns stored as strings
        if 'CryoSleep' in df.columns:
            df['CryoSleep'] = df['CryoSleep'].astype(bool)
        
        # 2. Parse Cabin information into Deck, Number, and Side
        if 'Cabin' in df.columns:
            cabin_parts = df['Cabin'].str.split('/', expand=True)
            df['Deck'] = cabin_parts[0] if cabin_parts.shape[1] > 0 else None
            df['Cabin_num'] = cabin_parts[1].astype(float) if cabin_parts.shape[1] > 1 else None
            df['Cabin_side'] = cabin_parts[2] if cabin_parts.shape[1] > 2 else None
        
        # 3. Create spending-related features
        spending_cols = ['RoomService', 'FoodCourt', 'ShoppingMall', 'Spa', 'VRDeck']
        
        # Fill missing spending values with 0 (logical assumption)
        for col in spending_cols:
            if col in df.columns:
                df[col] = df[col].fillna(0)
        
        # Create total spending feature
        if all(col in df.columns for col in spending_cols):
            df['TotalSpend'] = df[spending_cols].sum(axis=1)
            df['HasSpent'] = (df['TotalSpend'] > 0).astype(int)
        
        # 4. Age-related features
        if 'Age' in df.columns:
            # Fill missing age with median
            df['Age'] = df['Age'].fillna(df['Age'].median())
            
            # Create age groups based on EDA insights
            df['IsChild'] = (df['Age'] < 18).astype(int)
            df['AgeGroup'] = pd.cut(df['Age'], bins=[0, 18, 35, 50, 100], 
                                 labels=['Child', 'Young', 'Middle', 'Senior'])
        
        # 5. Family-related features from Name
        if 'Name' in df.columns:
            # Extract last name for family grouping
            df['LastName'] = df['Name'].str.split().str[-1]
            
            # Count family size (passengers with same last name)
            family_counts = df['LastName'].value_counts()
            df['FamilySize'] = df['LastName'].map(family_counts)
            df['TravelingAlone'] = (df['FamilySize'] == 1).astype(int)
        
        # 6. Handle missing values in categorical features
        categorical_cols = ['HomePlanet', 'Destination', 'Deck', 'Cabin_side']
        for col in categorical_cols:
            if col in df.columns:
                # Fill with most frequent value
                mode_val = df[col].mode()[0] if len(df[col].mode()) > 0 else 'Unknown'
                df[col] = df[col].fillna(mode_val)
        
        # 7. Handle missing CryoSleep based on spending patterns
        if 'CryoSleep' in df.columns and 'HasSpent' in df.columns:
            # If someone has spent money and CryoSleep is missing, likely not in CryoSleep
            cryosleep_mask = df['CryoSleep'].isna()
            df.loc[cryosleep_mask & (df['HasSpent'] == 1), 'CryoSleep'] = False
            df.loc[cryosleep_mask & (df['HasSpent'] == 0), 'CryoSleep'] = True
        
        # 8. Create interaction features
        if 'CryoSleep' in df.columns and 'HasSpent' in df.columns:
            df['CryoSleep_HasSpent'] = (df['CryoSleep'] & (df['HasSpent'] == 1)).astype(int)
        
        # 9. One-hot encode categorical features for linear regression compatibility
        categorical_features = ['HomePlanet', 'Destination', 'Deck', 'Cabin_side', 'AgeGroup']
        for feature in categorical_features:
            if feature in df.columns:
                dummies = pd.get_dummies(df[feature], prefix=feature, drop_first=True)
                df = pd.concat([df, dummies], axis=1)
        
        # 10. Convert boolean features to integers for consistency
        bool_cols = ['CryoSleep', 'VIP'] if 'VIP' in df.columns else ['CryoSleep']
        for col in bool_cols:
            if col in df.columns:
                df[col] = df[col].astype(int)
        
        # 11. Log transform heavily skewed spending features to reduce impact of outliers
        if 'TotalSpend' in df.columns:
            df['LogTotalSpend'] = np.log1p(df['TotalSpend'])  # log1p handles zeros
        
        # 12. Scale numerical features for linear regression
        numerical_features = ['Age', 'TotalSpend', 'LogTotalSpend', 'FamilySize', 'Cabin_num']
        from sklearn.preprocessing import StandardScaler
        
        for feature in numerical_features:
            if feature in df.columns:
                scaler = StandardScaler()
                df[feature + '_scaled'] = scaler.fit_transform(df[[feature]])
        
        # 13. Drop original categorical columns that have been encoded
        cols_to_drop = ['Cabin', 'Name', 'LastName'] + categorical_features
        cols_to_drop = [col for col in cols_to_drop if col in df.columns]
        df = df.drop(columns=cols_to_drop)
        
        # 14. Handle any remaining missing values
        for col in df.columns:
            if df[col].dtype in ['float64', 'int64'] and df[col].isna().any():
                df[col] = df[col].fillna(df[col].median())
            elif df[col].dtype == 'object' and df[col].isna().any():
                df[col] = df[col].fillna('Unknown')
        
        return df
